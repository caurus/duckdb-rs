#include "src/main/capi/aggregate_function-c.cpp"

#include "src/main/capi/appender-c.cpp"

#include "src/main/capi/arrow-c.cpp"

#include "src/main/capi/cast_function-c.cpp"

#include "src/main/capi/config-c.cpp"

#include "src/main/capi/data_chunk-c.cpp"

#include "src/main/capi/datetime-c.cpp"

#include "src/main/capi/duckdb-c.cpp"

#include "src/main/capi/duckdb_value-c.cpp"

#include "src/main/capi/helper-c.cpp"

#include "src/main/capi/hugeint-c.cpp"

#include "src/main/capi/logical_types-c.cpp"

#include "src/main/capi/pending-c.cpp"

#include "src/main/capi/prepared-c.cpp"

#include "src/main/capi/profiling_info-c.cpp"

#include "src/main/capi/replacement_scan-c.cpp"

#include "src/main/capi/result-c.cpp"

#include "src/main/capi/scalar_function-c.cpp"

#include "src/main/capi/stream-c.cpp"

#include "src/main/capi/table_description-c.cpp"

#include "src/main/capi/table_function-c.cpp"

#include "src/main/capi/threading-c.cpp"

#include "src/main/capi/value-c.cpp"

