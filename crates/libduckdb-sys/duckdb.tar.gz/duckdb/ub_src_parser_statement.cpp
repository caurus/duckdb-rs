#include "src/parser/statement/alter_statement.cpp"

#include "src/parser/statement/attach_statement.cpp"

#include "src/parser/statement/call_statement.cpp"

#include "src/parser/statement/copy_statement.cpp"

#include "src/parser/statement/copy_database_statement.cpp"

#include "src/parser/statement/create_statement.cpp"

#include "src/parser/statement/detach_statement.cpp"

#include "src/parser/statement/delete_statement.cpp"

#include "src/parser/statement/drop_statement.cpp"

#include "src/parser/statement/execute_statement.cpp"

#include "src/parser/statement/explain_statement.cpp"

#include "src/parser/statement/export_statement.cpp"

#include "src/parser/statement/extension_statement.cpp"

#include "src/parser/statement/insert_statement.cpp"

#include "src/parser/statement/load_statement.cpp"

#include "src/parser/statement/multi_statement.cpp"

#include "src/parser/statement/pragma_statement.cpp"

#include "src/parser/statement/prepare_statement.cpp"

#include "src/parser/statement/relation_statement.cpp"

#include "src/parser/statement/select_statement.cpp"

#include "src/parser/statement/set_statement.cpp"

#include "src/parser/statement/transaction_statement.cpp"

#include "src/parser/statement/update_statement.cpp"

#include "src/parser/statement/update_extensions_statement.cpp"

#include "src/parser/statement/vacuum_statement.cpp"

