#include "src/optimizer/statistics/operator/propagate_aggregate.cpp"

#include "src/optimizer/statistics/operator/propagate_cross_product.cpp"

#include "src/optimizer/statistics/operator/propagate_filter.cpp"

#include "src/optimizer/statistics/operator/propagate_get.cpp"

#include "src/optimizer/statistics/operator/propagate_limit.cpp"

#include "src/optimizer/statistics/operator/propagate_join.cpp"

#include "src/optimizer/statistics/operator/propagate_order.cpp"

#include "src/optimizer/statistics/operator/propagate_projection.cpp"

#include "src/optimizer/statistics/operator/propagate_set_operation.cpp"

#include "src/optimizer/statistics/operator/propagate_window.cpp"

