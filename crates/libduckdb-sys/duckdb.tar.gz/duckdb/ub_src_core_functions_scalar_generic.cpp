#include "src/core_functions/scalar/generic/alias.cpp"

#include "src/core_functions/scalar/generic/can_implicitly_cast.cpp"

#include "src/core_functions/scalar/generic/current_setting.cpp"

#include "src/core_functions/scalar/generic/error.cpp"

#include "src/core_functions/scalar/generic/hash.cpp"

#include "src/core_functions/scalar/generic/least.cpp"

#include "src/core_functions/scalar/generic/stats.cpp"

#include "src/core_functions/scalar/generic/typeof.cpp"

#include "src/core_functions/scalar/generic/system_functions.cpp"

